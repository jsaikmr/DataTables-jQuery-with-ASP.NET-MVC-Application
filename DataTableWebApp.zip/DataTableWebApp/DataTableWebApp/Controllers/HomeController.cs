﻿using DataTableWebApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DataTableWebApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            List<Product> productList = new List<Product>()
            {
                new Product() { ProductId=1001, ProductName="MotorCycle", Description="A two wheeler vehicle", Category="Two Wheeler"},
                new Product() { ProductId=1002, ProductName="Car", Description="A four wheeler vehicle", Category="Four Wheeler"}
            };

            return View(productList);
        }

        [HttpGet]
        public JsonResult GetProducts()
        {
            List<Product> productList = new List<Product>()
            {
                new Product() { ProductId=1001, ProductName="MotorCycle", Description="A two wheeler vehicle", Category="Two Wheeler"},
                new Product() { ProductId=1002, ProductName="Car", Description="A four wheeler vehicle", Category="Four Wheeler"}
            };

            return Json(new { data = productList }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}